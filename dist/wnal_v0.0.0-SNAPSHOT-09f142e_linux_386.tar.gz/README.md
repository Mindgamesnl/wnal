# wnal
Simple piece of software to access shell applications from the web
